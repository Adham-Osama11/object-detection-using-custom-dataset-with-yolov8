# slash > 2024-03-12 5:37pm
https://universe.roboflow.com/my-workspace-j6ggb/slash

Provided by a Roboflow user
License: CC BY 4.0

